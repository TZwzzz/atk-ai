#ifndef _IMPORT_FACE_LIBRARY_H
#define _IMPORT_FACE_LIBRARY_H

#include "rockx.h"
#include "face_database.h"

#define FEATURE_SIZE 512

rockx_handle_t face_det_handle;
rockx_handle_t face_5landmarks_handle;
rockx_handle_t face_recognize_handle;

rockx_object_t *get_max_face(rockx_object_array_t *face_array);
int run_face_recognize(const char *name, rockx_image_t *in_image, rockx_face_feature_t *out_feature);

#endif