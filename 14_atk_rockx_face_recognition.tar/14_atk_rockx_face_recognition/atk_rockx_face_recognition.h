#ifndef _ATK_ROCKX_FACE_RECOGNITION_H
#define _ATK_ROCKX_FACE_RECOGNITION_H

#include <assert.h>
#include <fcntl.h>
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "im2d.h"
#include "rga.h"
#include "rockx.h"
#include "rkmedia_api.h"
#include "sample_common.h"
#include "face_database.h"
#include "opencv2/opencv.hpp"
#include "opencv2/freetype.hpp"


# define RKAIQ 1
using namespace cv;

#define True 1
#define False 0

using namespace cv;
static bool quit = false;

void *rkmedia_vi_rockx_thread(void *args);
void *rkmedia_vo_rockx_thread(void *args);
void face_data_init();
static void print_usage(const RK_CHAR *name);
static void sigterm_handler(int sig);


#endif