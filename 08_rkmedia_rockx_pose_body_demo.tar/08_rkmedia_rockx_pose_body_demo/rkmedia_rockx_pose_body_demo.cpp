/****************************************************************************
*
*    Copyright (c) 2017 - 2019 by Rockchip Corp.  All rights reserved.
*
*    The material in this file is confidential and contains trade secrets
*    of Rockchip Corporation. This is proprietary information owned by
*    Rockchip Corporation. No part of this work may be disclosed,
*    reproduced, copied, transmitted, or used in any way for any purpose,
*    without the express written permission of Rockchip Corporation.
*
*****************************************************************************/

#include "rkmedia_rockx_pose_body_demo.h"

int main(int argc, char *argv[]) 
{
  int ret;
  int disp_width = 720;
  int disp_height = 1280;
  RK_U32 u32Loop = 0;
  RK_BOOL bIsHardware = RK_TRUE;
  CODEC_TYPE_E enCodecType = RK_CODEC_TYPE_H264;
  RK_CHAR *pcFileName = "/demo/bin/pose.h264";

  #define INBUF_SIZE 4096

  RK_MPI_SYS_Init();
  VDEC_CHN_ATTR_S stVdecAttr;
  stVdecAttr.enCodecType = enCodecType;
  stVdecAttr.enMode = VIDEO_MODE_STREAM;
  if (bIsHardware) 
  {
    if (stVdecAttr.enCodecType == RK_CODEC_TYPE_JPEG) 
    {
      stVdecAttr.enMode = VIDEO_MODE_FRAME;
    } 
    else 
    {
      stVdecAttr.enMode = VIDEO_MODE_STREAM;
    }
    stVdecAttr.enDecodecMode = VIDEO_DECODEC_HADRWARE;
  } 
  else 
  {
    stVdecAttr.enMode = VIDEO_MODE_FRAME;
    stVdecAttr.enDecodecMode = VIDEO_DECODEC_SOFTWARE;
  }
  ret = RK_MPI_VDEC_CreateChn(0, &stVdecAttr);
  if (ret) 
  {
    printf("ERROR: create Vdec[0] failed! ret=%d\n", ret);
    return -1;
  }

  RGA_ATTR_S stRgaAttr;
  memset(&stRgaAttr, 0, sizeof(stRgaAttr));
  stRgaAttr.bEnBufPool = RK_TRUE;
  stRgaAttr.u16BufPoolCnt = 3;
  stRgaAttr.u16Rotaion = 0;
  stRgaAttr.stImgIn.u32X = 0;
  stRgaAttr.stImgIn.u32Y = 0;
  stRgaAttr.stImgIn.imgType = IMAGE_TYPE_NV12; 
  stRgaAttr.stImgIn.u32Width = disp_width;
  stRgaAttr.stImgIn.u32Height = disp_height;
  stRgaAttr.stImgIn.u32HorStride = disp_width;
  stRgaAttr.stImgIn.u32VirStride = disp_height;
  stRgaAttr.stImgOut.u32X = 0;
  stRgaAttr.stImgOut.u32Y = 0;
  stRgaAttr.stImgOut.imgType = IMAGE_TYPE_RGB888;
  stRgaAttr.stImgOut.u32Width = disp_width;
  stRgaAttr.stImgOut.u32Height = disp_height;
  stRgaAttr.stImgOut.u32HorStride = disp_width;
  stRgaAttr.stImgOut.u32VirStride = disp_height;
  ret = RK_MPI_RGA_CreateChn(0, &stRgaAttr);
  if (ret) 
  {
    printf("ERROR: create RGA[0:0] falied! ret=%d\n", ret);
  }

  VO_CHN_ATTR_S stVoAttr = {0};
  stVoAttr.pcDevNode = "/dev/dri/card0";
  stVoAttr.emPlaneType = VO_PLANE_OVERLAY;
  stVoAttr.enImgType = IMAGE_TYPE_RGB888;
  stVoAttr.u16Zpos = 0;
  stVoAttr.stImgRect.s32X = 0;
  stVoAttr.stImgRect.s32Y = 0;
  stVoAttr.stImgRect.u32Width = disp_width;
  stVoAttr.stImgRect.u32Height = disp_height;
  stVoAttr.stDispRect.s32X = 0;
  stVoAttr.stDispRect.s32Y = 0;
  stVoAttr.stDispRect.u32Width = disp_width;
  stVoAttr.stDispRect.u32Height = disp_height;
  ret = RK_MPI_VO_CreateChn(0, &stVoAttr);
  if (ret) 
  {
    printf("ERROR: create VO[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  MPP_CHN_S stSrcChn;
  MPP_CHN_S stDestChn;
  printf("Bind VDEC[0:0] to RGA[0:0]....\n");
  stSrcChn.enModId = RK_ID_VDEC;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_Bind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: Bind VDEC[0:0] to RGA[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  pthread_t rkmedia_vi_rockx_tidp;
  pthread_create(&rkmedia_vi_rockx_tidp, NULL, rkmedia_rockx_thread, NULL);
  printf("%s initial finish\n", __func__);

  FILE *infile = fopen(pcFileName, "rb");
  if (!infile) 
  {
    fprintf(stderr, "Could not open %s\n", pcFileName);
    return 0;
  }

  int data_size;
  int read_size;
  if (stVdecAttr.enMode == VIDEO_MODE_STREAM) 
  {
    data_size = INBUF_SIZE;
  } 
  else if (stVdecAttr.enMode == VIDEO_MODE_FRAME)
  {
    fseek(infile, 0, SEEK_END);
    data_size = ftell(infile);
    fseek(infile, 0, SEEK_SET);
  }

  while (!quit) 
  {
    MEDIA_BUFFER mb = RK_MPI_MB_CreateBuffer(data_size, RK_FALSE, 0);
  RETRY:
    /* read raw data from the input file */
    read_size = fread(RK_MPI_MB_GetPtr(mb), 1, data_size, infile);
    if (!read_size || feof(infile)) 
    {
      if (u32Loop) 
      {
        fseek(infile, 0, SEEK_SET);
        goto RETRY;
      } 
      else 
      {
        RK_MPI_MB_ReleaseBuffer(mb);
        break;
      }
    }
    RK_MPI_MB_SetSize(mb, read_size);
    //printf("#Send packet(%p, %zuBytes) to VDEC[0].\n", RK_MPI_MB_GetPtr(mb),RK_MPI_MB_GetSize(mb));
    ret = RK_MPI_SYS_SendMediaBuffer(RK_ID_VDEC, 0, mb);
    RK_MPI_MB_ReleaseBuffer(mb);

    usleep(30 * 1000);
  }

  quit = true;
  pthread_join(rkmedia_vi_rockx_tidp, NULL);

  while (!quit) 
  {
    usleep(200000);
  }

  printf("Unbind VDEC[0:0] to RGA[0:0]....\n");
  stSrcChn.enModId = RK_ID_VDEC;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_UnBind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: unbind VDEC[0:0] to RGA[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  ret = RK_MPI_VDEC_DestroyChn(0);
  if (ret) 
  {
    printf("ERROR: destroy VDEC[0:0] error! ret=%d\n", ret);
    return -1;
  }
  
  ret = RK_MPI_RGA_DestroyChn(0);
  if (ret) 
  {
    printf("ERROR: destroy RGA[0:0] error! ret=%d\n", ret);
    return -1;
  }

  printf("Destroy VO[0:0] channel\n");
  ret = RK_MPI_VO_DestroyChn(0);
  if (ret) 
  {
    printf("ERROR: destroy VO[0:0] error! ret=%d\n", ret);
    return -1;
  }

  fclose(infile);
  return 0;
}



void *rkmedia_rockx_thread(void *args) 
{
  rockx_ret_t ret;
  rockx_handle_t pose_body_handle;
  
  char *rockx_data = "/demo/src/rockx_data";
  rockx_config_t *config = rockx_create_config();
  rockx_add_config(config, ROCKX_CONFIG_DATA_PATH, rockx_data);

  rockx_module_t pose_module = ROCKX_MODULE_POSE_BODY_V2;
  //rockx_module_t pose_module = ROCKX_MODULE_POSE_BODY;

  if(pose_module == ROCKX_MODULE_POSE_BODY_V2)
  {
    ret = rockx_create(&pose_body_handle, ROCKX_MODULE_POSE_BODY_V2, config, sizeof(rockx_config_t));
    if (ret != ROCKX_RET_SUCCESS) 
    {
      printf("ERROR: init rockx module ROCKX_MODULE_POSE_BODY_V2 error %d\n", ret);
    }
  }

  if(pose_module == ROCKX_MODULE_POSE_BODY)
  {
    ret = rockx_create(&pose_body_handle, ROCKX_MODULE_POSE_BODY, config, sizeof(rockx_config_t));
    if (ret != ROCKX_RET_SUCCESS) 
    {
      printf("ERROR: init rockx module ROCKX_MODULE_POSE_BODY error %d\n", ret);
    }
  }

  while (!quit) 
  {
    MEDIA_BUFFER src_mb = NULL;

    src_mb = RK_MPI_SYS_GetMediaBuffer(RK_ID_RGA, 0, -1);
    if (!src_mb) 
    {
      printf("ERROR: RK_MPI_SYS_GetMediaBuffer get null buffer!\n");
      break;
    }
     
    rockx_image_t input_image;
    rkMB_IMAGE_INFO ImageInfo={0};
    int ret=RK_MPI_MB_GetImageInfo(src_mb,&ImageInfo);
    if (ret) 
    {
      printf("ERROR: RK_MPI_MB_GetImageInfo get image info failed! ret = %d\n", ret);
      RK_MPI_MB_ReleaseBuffer(src_mb);
      return NULL;
    }

    input_image.width=ImageInfo.u32Width;   
    input_image.height=ImageInfo.u32Height;
    input_image.pixel_format = ROCKX_PIXEL_FORMAT_RGB888;
    input_image.size = RK_MPI_MB_GetSize(src_mb);
    input_image.data = (uint8_t *)RK_MPI_MB_GetPtr(src_mb);

    rockx_keypoints_array_t body_array;
    memset(&body_array, 0, sizeof(rockx_keypoints_array_t));
    ret = rockx_pose_body(pose_body_handle, &input_image, &body_array, nullptr);
    if (ret != ROCKX_RET_SUCCESS) 
    {
      printf("ERROR: rockx_pose_body error %d\n", ret);
    }

    const std::vector<std::pair<int,int>> posePairs_v1 = 
    {
    	{1,2}, {1,5}, {2,3}, {3,4}, {5,6}, {6,7},
    	{1,8}, {8,9}, {9,10}, {1,11}, {11,12}, {12,13},
    	{1,0}, {0,14}, {14,16}, {0,15}, {15,17}
    };

    const std::vector<std::pair<int,int>> posePairs_v2 = 
    {
        {2,3}, {3,4}, {5,6}, {6,7},
        {8,9}, {9,10}, {11,12}, {12,13},
        {1,0}, {0,14}, {14,16}, {0,15}, {15,17},
        {2,5}, {8,11}, {2,8}, {5,11}
    };

    std::vector<std::pair<int,int>> posePairs;
    if (pose_module == ROCKX_MODULE_POSE_BODY)
    {
      posePairs = posePairs_v1;
    }
    else if (pose_module == ROCKX_MODULE_POSE_BODY_V2)
    {
      posePairs = posePairs_v2;
    }
        
    for (int i = 0; i < body_array.count; i++) 
    {
      //printf("person %d:\n", i);

      for(int j = 0; j < body_array.keypoints[i].count; j++) 
      {
        int x = body_array.keypoints[i].points[j].x;
        int y = body_array.keypoints[i].points[j].y;
        float score = body_array.keypoints[i].score[j];
        //printf("  %s [%d, %d] %f\n", ROCKX_POSE_BODY_KEYPOINTS_NAME[j], x, y, score);
        if (x>0 && y>0)
        {
          // 使用rockx的API来画圆
          rockx_image_draw_circle(&input_image, {x, y}, 10, {255, 0, 0}, -1);

          /*
          // 使用opencv来画圆
          using namespace cv;
          Mat show_img = Mat(input_image.height, input_image.width, CV_8UC3,RK_MPI_MB_GetPtr(src_mb));
          cv::circle(show_img,cv::Point(x, y),10,Scalar(255,0,0),-1);
          show_img.release();
          */
        }
      }

      for(int j = 0; j < posePairs.size(); j ++) 
      {
        const std::pair<int,int>& posePair = posePairs[j];
        int x0 = body_array.keypoints[i].points[posePair.first].x;
        int y0 = body_array.keypoints[i].points[posePair.first].y;
        int x1 = body_array.keypoints[i].points[posePair.second].x;
        int y1 = body_array.keypoints[i].points[posePair.second].y;

        if( x0 > 0 && y0 > 0 && x1 > 0 && y1 > 0) 
        {
          // 使用rockx的API来画线
          rockx_image_draw_line(&input_image, {x0, y0}, {x1, y1}, {0, 255, 0}, 3);
          
          /*
          // 使用opencv来画线
          using namespace cv;
          Mat show_img = Mat(input_image.height, input_image.width, CV_8UC3,RK_MPI_MB_GetPtr(src_mb));
          cv::line(show_img,cv::Point(x0, y0),cv::Point(x1, y1),Scalar(0,255,0),3,8,0);
          show_img.release();
          */
        }
      }
    }

    RK_MPI_SYS_SendMediaBuffer(RK_ID_VO, 0, src_mb);
    RK_MPI_MB_ReleaseBuffer(src_mb);
    src_mb = NULL;
  }
  
  rockx_destroy(pose_body_handle);
  return NULL;
}
