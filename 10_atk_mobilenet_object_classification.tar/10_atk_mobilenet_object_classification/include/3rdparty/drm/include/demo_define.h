/*

 */

#ifndef DEFINE_H_
#define DEFINE_H_
//�ڴ˴���������ͷ�ļ�



#define S7_EDGE					1
#define GZ						2
#define DVR						3
/*
#define ISP_BAYER_NR            1
#define ISP_DPC                 2
#define ISP_BLC                 3
#define ISP_STAT_3A             4
#define ISP_LSC                 5
#define ISP_AWBG                6
#define ISP_VHDM                7
#define ISP_GAMMA               8
#define ISP_CSM                 9
#define ISP_DRC                 10
#define ISP_RGB2YUV             11
#define ISP_LCE                 12
#define ISP_Y_NR                13
#define ISP_SHARPEN             14
#define ISP_SCALING             15
#define ISP_GIC                 16
#define ISP_UV_NR               17
#define ISP_HDR_MERGE           18
#define ISP_HDR_TMO             19
#define ISP_DPN                 20
#define ISP_CTK                 21
#define ISP_WDR                 22
*/
#define SAVE_RESULT             1


//#define GET_LSC_CALIBRATION_DATA       //��ȡlens shadingУ���궨����


#endif  // DEFINE_H_
