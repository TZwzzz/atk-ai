// Copyright 2020 Fuzhou Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "atk_zbar_recognize.h"

int main(int argc, char *argv[])
{
  RK_CHAR *pDeviceName_01 = "rkispp_scale0";
  RK_CHAR *pcDevNode = "/dev/dri/card0";
  char *iq_file_dir = "/etc/iqfiles";
  RK_S32 s32CamId = 0;
  RK_U32 u32BufCnt = 3;
  RK_U32 fps = 30;
  int ret = 0;

  int c;

  printf("\n###############################################\n");
  printf("VI CameraIdx: %d\npDeviceName: %s\nResolution: %dx%d\n\n",
          s32CamId,pDeviceName_01,video_width,video_height);

  printf("VO pcDevNode: %s\nResolution: %dx%d\n",
          pcDevNode,disp_width,disp_height);
  printf("###############################################\n\n");

  if (iq_file_dir) 
  {
#ifdef RKAIQ
  printf("#Rkaiq XML DirPath: %s\n", iq_file_dir);
  rk_aiq_working_mode_t hdr_mode = RK_AIQ_WORKING_MODE_NORMAL;
  SAMPLE_COMM_ISP_Init(s32CamId,hdr_mode, RK_FALSE,iq_file_dir);
  SAMPLE_COMM_ISP_Run(s32CamId);
  SAMPLE_COMM_ISP_SetFrameRate(s32CamId,fps);
#endif
  }

  RK_MPI_SYS_Init();
  VI_CHN_ATTR_S vi_chn_attr;
  memset(&vi_chn_attr, 0, sizeof(vi_chn_attr));
  vi_chn_attr.pcVideoNode = pDeviceName_01;
  vi_chn_attr.u32BufCnt = u32BufCnt;
  vi_chn_attr.u32Width = video_width;
  vi_chn_attr.u32Height = video_height;
  vi_chn_attr.enPixFmt = IMAGE_TYPE_NV12;
  vi_chn_attr.enBufType = VI_CHN_BUF_TYPE_MMAP;
  vi_chn_attr.enWorkMode = VI_WORK_MODE_NORMAL;
  ret = RK_MPI_VI_SetChnAttr(s32CamId, 0, &vi_chn_attr);
  ret |= RK_MPI_VI_EnableChn(s32CamId, 0);
  if (ret)
  {
    printf("ERROR: create VI[0:0] error! ret=%d\n", ret);
    return -1;
  }

  RGA_ATTR_S stRgaAttr_01;
  memset(&stRgaAttr_01, 0, sizeof(stRgaAttr_01));
  stRgaAttr_01.bEnBufPool = RK_TRUE;
  stRgaAttr_01.u16BufPoolCnt = u32BufCnt;
  stRgaAttr_01.u16Rotaion = 270;
  stRgaAttr_01.stImgIn.u32X = 0;
  stRgaAttr_01.stImgIn.u32Y = 0;
  stRgaAttr_01.stImgIn.imgType = IMAGE_TYPE_NV12;
  stRgaAttr_01.stImgIn.u32Width = video_width;
  stRgaAttr_01.stImgIn.u32Height = video_height;
  stRgaAttr_01.stImgIn.u32HorStride = video_width;
  stRgaAttr_01.stImgIn.u32VirStride = video_height;
  stRgaAttr_01.stImgOut.u32X = 0;
  stRgaAttr_01.stImgOut.u32Y = 0;
  stRgaAttr_01.stImgOut.imgType = IMAGE_TYPE_RGB888;
  stRgaAttr_01.stImgOut.u32Width = disp_width;
  stRgaAttr_01.stImgOut.u32Height = disp_height;
  stRgaAttr_01.stImgOut.u32HorStride = disp_width;
  stRgaAttr_01.stImgOut.u32VirStride = disp_height;
  ret = RK_MPI_RGA_CreateChn(0, &stRgaAttr_01);
  if (ret) 
  {
    printf("ERROR: create RGA[0:0] falied! ret=%d\n", ret);
    return -1;
  } 

  VO_CHN_ATTR_S stVoAttr = {0};
  stVoAttr.pcDevNode = pcDevNode;
  stVoAttr.emPlaneType = VO_PLANE_PRIMARY;
  stVoAttr.enImgType = IMAGE_TYPE_RGB888;
  stVoAttr.u16Zpos = 0;
  stVoAttr.stDispRect.s32X = 0;
  stVoAttr.stDispRect.s32Y = 0;
  stVoAttr.stDispRect.u32Width = disp_width;
  stVoAttr.stDispRect.u32Height = disp_height;
  ret = RK_MPI_VO_CreateChn(0, &stVoAttr);
  if (ret)
  {
    printf("ERROR: create VO[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  RGA_ATTR_S stRgaAttr_02;
  memset(&stRgaAttr_02, 0, sizeof(stRgaAttr_02));
  stRgaAttr_02.bEnBufPool = RK_TRUE;
  stRgaAttr_02.u16BufPoolCnt = u32BufCnt;
  stRgaAttr_02.u16Rotaion = 0;
  stRgaAttr_02.stImgIn.u32X = 0;
  stRgaAttr_02.stImgIn.u32Y = 0;
  stRgaAttr_02.stImgIn.imgType = IMAGE_TYPE_NV12;
  stRgaAttr_02.stImgIn.u32Width = video_width;
  stRgaAttr_02.stImgIn.u32Height = video_height;
  stRgaAttr_02.stImgIn.u32HorStride = video_width;
  stRgaAttr_02.stImgIn.u32VirStride = video_height;
  stRgaAttr_02.stImgOut.u32X = 0;
  stRgaAttr_02.stImgOut.u32Y = 0;
  stRgaAttr_02.stImgOut.imgType = IMAGE_TYPE_NV12;
  stRgaAttr_02.stImgOut.u32Width = zbar_width;
  stRgaAttr_02.stImgOut.u32Height = zbar_height;
  stRgaAttr_02.stImgOut.u32HorStride = zbar_width;
  stRgaAttr_02.stImgOut.u32VirStride = zbar_height;
  ret = RK_MPI_RGA_CreateChn(1, &stRgaAttr_02);
  if (ret) 
  {
    printf("ERROR: create RGA[0:1] falied! ret=%d\n", ret);
    return -1;
  } 

  pthread_t zbar_tidp;
  pthread_create(&zbar_tidp, NULL, rkmedia_zbar_thread, NULL);

  MPP_CHN_S stSrcChn;
  MPP_CHN_S stDestChn;
  printf("Bind VI[0:0] to RGA[0:0]....\n");
  stSrcChn.enModId = RK_ID_VI;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_Bind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: bind VI[0:0] to RGA[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  printf("Bind RGA[0:0] to VO[0:0]....\n");
  stSrcChn.enModId = RK_ID_RGA;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_VO;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_Bind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: bind RGA[0:0] to VO[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  printf("Bind VI[0:0] to RGA[0:1]....\n");
  stSrcChn.enModId = RK_ID_VI;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 1;
  ret = RK_MPI_SYS_Bind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: bind VI[0:0] to RGA[0:1] failed! ret=%d\n", ret);
    return -1;
  }

  printf("%s initial finish\n", __func__);
  signal(SIGINT, sigterm_handler);

  pthread_t time_delay_tidp;
  pthread_create(&time_delay_tidp, NULL, time_delay, NULL);

  while (!quit)
  {
    usleep(500000);
  }

  pthread_join(zbar_tidp, NULL);
  pthread_join(time_delay_tidp, NULL);

  printf("UnBind VI[0:0] to RGA[0:0]....\n");
  stSrcChn.enModId = RK_ID_VI;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_UnBind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: unbind VI[0:0] to RGA[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  printf("UnBind VI[0:0] to RGA[0:1]....\n");
  stSrcChn.enModId = RK_ID_VI;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_RGA;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 1;
  ret = RK_MPI_SYS_UnBind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: unbind VI[0:0] to RGA[0:1] failed! ret=%d\n", ret);
    return -1;
  }

  printf("UnBind VI[0:0] to VO[0:0]....\n");
  stSrcChn.enModId = RK_ID_RGA;
  stSrcChn.s32DevId = s32CamId;
  stSrcChn.s32ChnId = 0;
  stDestChn.enModId = RK_ID_VO;
  stDestChn.s32DevId = s32CamId;
  stDestChn.s32ChnId = 0;
  ret = RK_MPI_SYS_UnBind(&stSrcChn, &stDestChn);
  if (ret) 
  {
    printf("ERROR: unbind VI[0:0] to VO[0:0] failed! ret=%d\n", ret);
    return -1;
  }

  RK_MPI_VO_DestroyChn(0);
  RK_MPI_RGA_DestroyChn(0);
  RK_MPI_RGA_DestroyChn(1);
  RK_MPI_VI_DisableChn(s32CamId, 0);
  
  if (iq_file_dir) 
  {
#if RKAIQ
    SAMPLE_COMM_ISP_Stop(s32CamId);
#endif
  }
  return 0;
}


static void *rkmedia_zbar_thread(void *arg)
{
  MEDIA_BUFFER src_mb = NULL;
  pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  void *buff;

  while (!quit)
  {
    src_mb = RK_MPI_SYS_GetMediaBuffer(RK_ID_RGA, 1, -1);
    if (!src_mb)
    {
      printf("ERROR: RK_MPI_SYS_GetMediaBuffer get null buffer!\n");
      continue;
    }

    if (flag)
    {
      void *data = RK_MPI_MB_GetPtr(src_mb);
      if (data == NULL)
      {
        printf("RK_MPI_MB_GetPtr get null buffer!\n");
        continue;
      }
      size_t size = RK_MPI_MB_GetSize(src_mb);
      void *buff = malloc(size);
      memset(buff, 0, sizeof(buff));
      pthread_mutex_lock(&mutex);
      memcpy(buff, data, size);
      flag = false;
      pthread_mutex_unlock(&mutex);

      // zbar image scan
      zbar_image_scanner_t *scanner = NULL;
      zbar_image_t *image = NULL;
      zbar_image_t *scan_img = NULL;
      scanner = zbar_image_scanner_create();
      zbar_image_scanner_set_config(scanner, ZBAR_NONE, ZBAR_CFG_ENABLE, 1);
      image = zbar_image_create();
      zbar_image_set_format(image, zbar_fourcc('N', 'V', '1', '2'));
      zbar_image_set_size(image, zbar_width, zbar_height);
      zbar_image_set_data(image, buff, zbar_width * zbar_height, NULL);
      scan_img = zbar_image_convert(image, zbar_fourcc('Y', '8', '0', '0'));
      //scan_img = zbar_image_convert(image, *(int*)"Y800");
    
      /* scan the image for barcodes */
      int n = zbar_scan_image(scanner, scan_img);
      const zbar_symbol_t *symbol = zbar_image_first_symbol(scan_img);
      if (NULL == symbol)
      {
        goto free;
      }
      for (; symbol; symbol = zbar_symbol_next(symbol))
      {
        zbar_symbol_type_t typ = zbar_symbol_get_type(symbol);
        const char *data = zbar_symbol_get_data(symbol);
        if (data != NULL)
        {
          printf("\n********************\n");
          printf("zbar_symbol: %s\n", zbar_get_symbol_name(typ));
          printf("zbar_data:   %s\n", data);
          printf("********************\n");
        }
      }
    free:
      zbar_image_destroy(image);
      zbar_image_destroy(scan_img);
      zbar_image_scanner_destroy(scanner);
      free(buff);
    }

    if (quit)
    {
      break;
    }

    RK_MPI_MB_ReleaseBuffer(src_mb);
  }
  free(buff);
  return NULL;
}


static void *time_delay(void *arg)
{
  while (!quit)
  {
    flag = true;
    usleep(1000 * 1000);
  }
  return NULL;
}


static void sigterm_handler(int sig)
{
  fprintf(stderr, "signal %d\n", sig);
  quit = true;
}
