#ifndef _ATK_ZBAR_RECOGNIZE_H
#define _ATK_ZBAR_RECOGNIZE_H

#include <getopt.h>
#include <math.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>

#include "zbar.h"
#include "im2d.h"
#include "rga.h"
#include "rknn_api.h"
#include "rkmedia_api.h"
#include "sample_common.h"
#include "opencv2/opencv.hpp"

using namespace zbar;

RK_U32 video_width = 1920;
RK_U32 video_height = 1080;
int disp_width = 720;
int disp_height = 1280;
RK_U32 zbar_width= 640;
RK_U32 zbar_height= 360;

static bool quit = false;

static bool flag = false;
static char *result = NULL;

static void *rkmedia_zbar_thread(void *arg);
static void *time_delay(void *arg);
static void sigterm_handler(int sig);

#endif